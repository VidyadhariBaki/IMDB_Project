### Location Data Service
A Service that manages location data
