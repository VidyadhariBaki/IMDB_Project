package com.boeing.onepdl.loc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocDataServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocDataServiceApplication.class, args);
	}

}
