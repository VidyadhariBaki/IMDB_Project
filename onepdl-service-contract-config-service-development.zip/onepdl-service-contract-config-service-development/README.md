# onepdl-service-contract-config-service
A ServiceContract Config CRUD Service

