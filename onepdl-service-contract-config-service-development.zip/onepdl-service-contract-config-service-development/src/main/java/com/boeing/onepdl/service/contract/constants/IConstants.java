package com.boeing.onepdl.service.contract.constants;

public interface IConstants {

	// Exception
	public static final String EXCEPTION_OCCURED_WHILE_PROCESSING = "Exception occured while processing the request! ";
	public static final String EXCEPTION_OCCURED_WHILE_PARSING = "Exception occured while parsing the request! ";

}
