import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-coupons',
  templateUrl: './new-coupons.component.html',
  styleUrls: ['./new-coupons.component.css']
})
export class NewCouponsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
