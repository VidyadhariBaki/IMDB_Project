package com.forget.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.forget.model.Customer;

@Repository
public interface ForgetRepository extends MongoRepository<Customer, String> {

}
