package com.forget.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.forget.model.Customer;
import com.forget.repository.ForgetRepository;
import com.netflix.ribbon.proxy.annotation.Http;


	
@CrossOrigin(origins ="http://localhost:4200")
@RestController
@RequestMapping("/api")
public class ForgetController {
	
	@Autowired
	ForgetRepository repo;
	
	 
	 @PostMapping("/pwd/forget")
	  public Customer validateUser(@RequestBody Customer customer) {
		System.out.println("Hiii Heloooo");
		System.out.println(customer);
			List<Customer> forget=repo.findAll();
			System.out.println(forget);
		  	for(Customer dblog:forget) {		  	
		  		if(dblog.getUsername().equals(customer.getUsername())) {
		  			System.out.println("its there");
		  			return dblog;
		  			//return ResponseEntity<dblog.getPassword()>,HttpStatus.OK>;
		  	}
		  }
		  	return null;
		  }
}
