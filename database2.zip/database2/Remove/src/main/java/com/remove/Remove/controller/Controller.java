package com.remove.Remove.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.remove.Remove.Repository.AdminRepository;
import com.remove.Remove.model.Customer;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/admin")
public class Controller {
 
	@Autowired
    AdminRepository repository;


  @GetMapping("/customer")
  public List<Customer> getAllCustomers() {
   return  repository.findAll();
  }
 
   @DeleteMapping("/customer/{username}")
 public boolean deleteCustomer(@PathVariable("username") String username) 
 {
	  List<Customer> customers=repository.findAll(); 
	  for(Customer customer:customers) {
		  if(customer.getUsername().equals(username)) {
			  repository.deleteById(username);
			   return true;
		  }
	  }
	  return false;
  
 
//   return new ResponseEntity<>("Customer has been deleted!", HttpStatus.OK);
	  
	  
  
 }
  
  
  }
