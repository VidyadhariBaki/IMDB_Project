package com.cg.addcart.addcart.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection ="cartdetails")
public class Customer {
	
private String username;
private String imageUrl;
private int price;

public Customer() {
	super();
}
public Customer(String username, String imageUrl, int price) {
	super();
	this.username = username;
	this.imageUrl = imageUrl;
	this.price = price;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getImageUrl() {
	return imageUrl;
}
public void setImageUrl(String imageUrl) {
	this.imageUrl = imageUrl;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
@Override
public String toString() {
	return "Customer [username=" + username + ", imageUrl=" + imageUrl + ", price=" + price + "]";
}

	

}
