package com.coupon.Coupon.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.coupon.Coupon.model.Customer;
import com.coupon.Coupon.repository.CouponRepository;

@CrossOrigin(origins ="http://localhost:4200")

	@RestController
	@RequestMapping("/payment")
	public class CouponController {
		
		@Autowired
		CouponRepository repository;
		
		//@PostMapping("/coupon/getCoupon")
//		 public List<String> validateUser(@RequestBody Customer userlog) {
//		 List<String> coupon=new ArrayList<String>();
//				List<Customer> login=repository.findAll();   
//			for(Customer dblog:login) {
//				
//				if(dblog.getUsername().equals(userlog.getUsername())) {
//					String temp=dblog.getCouponName()+"   "+dblog.getCouponCode();
//					coupon.add(temp);	 
//				}
//			
//		}
//			return coupon;
//		}
		
		@GetMapping("/coupon/getCoupon")
		public List<Customer> getDetails()

{
List<Customer> customer=new ArrayList<>();
repository.findAll().forEach(customer::add);;
return customer;
}
}


