package com.coupon.Coupon.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection ="coupondetails")
public class Customer {
	
	

	private String username;
	int couponCode;
	private String imageUrl;
	
	public Customer()
	{
		super();
	}

	public Customer(String username, int couponCode, String imageUrl) {
		super();
		this.username = username;
		this.couponCode = couponCode;
		this.imageUrl = imageUrl;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(int couponCode) {
		this.couponCode = couponCode;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	@Override
	public String toString() {
		return "Customer [username=" + username + ", couponCode=" + couponCode + ", imageUrl=" + imageUrl + "]";
	}

}