package com.coupon.Coupon.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.coupon.Coupon.model.Customer;


@Repository
public interface CouponRepository extends MongoRepository<Customer, String> {


}

